package com.CourseCompass.DatasourceAgent.Entity.mapper;

import com.CourseCompass.DatasourceAgent.Entity.CourseInfo;
import com.CourseCompass.DatasourceAgent.Entity.dto.CourseInfoRecord;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface CourseInfoMapper {
    CourseInfo dtoToCourseInfo(CourseInfoRecord dto);

    CourseInfoRecord courseInfoToDto(CourseInfo courseInfo);
}
