package com.CourseCompass.DatasourceAgent.Repository;


import com.CourseCompass.DatasourceAgent.Entity.CourseInfo;
import org.springframework.data.repository.CrudRepository;

public interface CourseInfoRepo extends CrudRepository<CourseInfo,Integer> {

}
